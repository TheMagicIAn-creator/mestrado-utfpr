"""
config.py — Al IAdo PV / Núcleo
Configuração central do projeto.

Este módulo é o ponto único de verdade para caminhos, constantes
e parâmetros. Todos os demais módulos importam daqui, em vez de
recalcular caminhos ou redefinir constantes localmente.

Autor: Rodolfo Torres (UTFPR)
"""

import os
from pathlib import Path
from dotenv import load_dotenv


# ============================================================
# RAIZ DO PROJETO
# ============================================================
# Este arquivo está em: <raiz>/src/core/config.py
# Portanto, a raiz do projeto está três níveis acima.
# Calculado UMA vez aqui; todos os módulos importam os caminhos prontos.

RAIZ_PROJETO = Path(__file__).resolve().parent.parent.parent


# ============================================================
# VARIÁVEIS DE AMBIENTE
# ============================================================
# Carrega o arquivo .env da raiz do projeto.

load_dotenv(RAIZ_PROJETO / ".env")

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GROQ_API_KEY   = os.getenv("GROQ_API_KEY")


# ============================================================
# CAMINHOS DE PASTAS
# ============================================================

PASTA_LITERATURA   = RAIZ_PROJETO / "literatura"
PASTA_DADOS        = RAIZ_PROJETO / "dados"
PASTA_DADOS_BRUTOS = PASTA_DADOS / "brutos"
PASTA_DADOS_PROC   = PASTA_DADOS / "processados"
PASTA_RESULTADOS   = RAIZ_PROJETO / "resultados"
PASTA_NOTAS        = RAIZ_PROJETO / "notas"
PASTA_SESSOES      = PASTA_NOTAS / "sessoes"
PASTA_MEMORIAS     = PASTA_NOTAS / "memorias"
PASTA_ARQUIVO      = PASTA_NOTAS / "sessoes_arquivadas"
PASTA_NOVOS_PDFS   = RAIZ_PROJETO / "novos_pdfs"
PASTA_CHROMADB     = RAIZ_PROJETO / "base_conhecimento"
ARQUIVO_PERFIL     = RAIZ_PROJETO / "CLAUDE.md"


# ============================================================
# CONSTANTES DO AGENTE (RAG)
# ============================================================

MODELO_EMBEDDINGS      = "paraphrase-multilingual-MiniLM-L12-v2"
MODELO_GEMINI          = "gemini-2.5-flash"
NOME_COLECAO           = "literatura_pv"
NOME_COLECAO_SESSOES   = "sessoes_pv"
N_RESULTADOS           = 25
TAMANHO_CHUNK          = 500
SOBREPOSICAO           = 50
TAMANHO_LOTE           = 500   # limite de upsert do ChromaDB


# ============================================================
# CONSTANTES DO MACHINE LEARNING
# ============================================================

TAXA_AMOSTRAGEM = 10_000   # Hz — dataset de inversor (Paderborn)
SEMENTE_ALEATORIA = 42     # random_state — reprodutibilidade


# ============================================================
# VERIFICAÇÃO DE INTEGRIDADE
# ============================================================

def verificar_estrutura() -> dict:
    """
    Verifica quais pastas essenciais existem.
    Útil para o orquestrador decidir o que precisa ser criado.
    """
    pastas = {
        "literatura"    : PASTA_LITERATURA,
        "dados_brutos"  : PASTA_DADOS_BRUTOS,
        "resultados"    : PASTA_RESULTADOS,
        "sessoes"       : PASTA_SESSOES,
        "novos_pdfs"    : PASTA_NOVOS_PDFS,
        "chromadb"      : PASTA_CHROMADB,
    }
    return {nome: caminho.exists() for nome, caminho in pastas.items()}


if __name__ == "__main__":
    print("=" * 60)
    print("  AL IADO PV — CONFIGURAÇÃO CENTRAL")
    print("=" * 60)
    print(f"\nRaiz do projeto: {RAIZ_PROJETO}")
    print(f"\nChave Google : {'✅ configurada' if GOOGLE_API_KEY else '❌ ausente'}")
    print(f"Chave Groq   : {'✅ configurada' if GROQ_API_KEY else '❌ ausente'}")
    print(f"\nEstrutura de pastas:")
    for nome, existe in verificar_estrutura().items():
        status = "✅" if existe else "❌"
        print(f"   {status} {nome}")
    print("=" * 60)