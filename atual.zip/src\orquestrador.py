"""
orquestrador.py - Al IAdo PV
Coordena a execucao do fluxo no backend.

PRINCIPIO DE DESIGN:
  A inicializacao do app (executar_pipeline) faz APENAS trabalho leve
  e rapido: verificar estado e indexar PDFs novos. Operacoes pesadas
  -- consolidacao de memoria, reprocessamento via LLM, pipeline de ML --
  NUNCA rodam na inicializacao. Elas sao acionadas sob demanda:
    - consolidacao de memoria  -> agendador do watcher (sexta / 3 dias)
    - reprocessamento de PDFs  -> sinal REPROCESSAR ou botao
    - pipeline de ML           -> botoes da aba ML no Streamlit

Isso garante que o app abra em segundos, sem travar.

Autor: Rodolfo Torres (UTFPR)
"""

from pathlib import Path

from src.core.config import (
    PASTA_NOVOS_PDFS, PASTA_SESSOES, PASTA_RESULTADOS,
    PASTA_CHROMADB, RAIZ_PROJETO,
)


# ============================================================
# VERIFICACOES DE ESTADO
# ============================================================

def ha_pdfs_novos() -> bool:
    """Verifica se ha PDFs aguardando indexacao em novos_pdfs/."""
    if not PASTA_NOVOS_PDFS.exists():
        return False
    return any(PASTA_NOVOS_PDFS.glob("*.pdf"))


def ha_sessoes_para_consolidar(minimo: int = 2) -> bool:
    """Verifica se ha acumulo de sessoes que justifique consolidacao."""
    if not PASTA_SESSOES.exists():
        return False
    return len(list(PASTA_SESSOES.glob("*.md"))) >= minimo


def ha_arquivos_com_nome_ruim() -> bool:
    """Verifica se ha PDFs com 'autor-desconhecido' no nome."""
    from src.core.config import PASTA_LITERATURA
    return any(PASTA_LITERATURA.rglob("autor-desconhecido_*.pdf"))


def ha_sinal_reprocessamento() -> bool:
    """Verifica se existe o arquivo REPROCESSAR na raiz do projeto."""
    return (RAIZ_PROJETO / "REPROCESSAR").exists()


def eda_pendente() -> bool:
    """Verifica se a analise exploratoria ainda nao foi gerada."""
    pasta = PASTA_RESULTADOS / "eda"
    return not pasta.exists() or not any(pasta.iterdir())


def classificacao_pendente() -> bool:
    """Verifica se a classificacao de ML ainda nao foi gerada."""
    pasta = PASTA_RESULTADOS / "classificacao_pv"
    return not pasta.exists() or not any(pasta.iterdir())


def features_ca_pendente() -> bool:
    return not (RAIZ_PROJETO / "dados" / "processados" /
                "features_paderborn.parquet").exists()


def autoencoder_pendente() -> bool:
    return not (RAIZ_PROJETO / "resultados" / "autoencoder" /
                "modelo_autoencoder.pt").exists()


def injecao_falhas_pendente() -> bool:
    return not (RAIZ_PROJETO / "resultados" / "autoencoder" /
                "injecao_falhas_report.json").exists()


def validacao_pendente() -> bool:
    return not (RAIZ_PROJETO / "resultados" / "autoencoder" /
                "validacao_report.json").exists()


def rul_weibull_pendente() -> bool:
    return not (RAIZ_PROJETO / "resultados" / "autoencoder" /
                "weibull_results.json").exists()


# ============================================================
# ETAPA LEVE - INDEXACAO DE PDFs NOVOS
# ============================================================

def etapa_indexar_pdfs(modelo_embeddings) -> str:
    """Indexa PDFs novos da pasta novos_pdfs/, se houver. Operacao rapida."""
    if not ha_pdfs_novos():
        return "PDFs novos: nenhum pendente"
    try:
        from src.conhecimento.processador_pdf import processar_pasta
        processar_pasta(PASTA_NOVOS_PDFS, modelo_embeddings, PASTA_CHROMADB)
        return "PDFs novos: indexados com sucesso"
    except Exception as e:
        return f"PDFs novos: erro - {e}"


# ============================================================
# REPROCESSAMENTO DE METADADOS (sob demanda)
# ============================================================

def reprocessar_metadados_ruins() -> str:
    """
    Detecta PDFs com 'autor-desconhecido' no nome, extrai metadados via LLM,
    renomeia e reindexa. Operacao PESADA - chamada apenas sob demanda,
    nunca na inicializacao do app.
    """
    from src.core.config import (PASTA_LITERATURA, PASTA_CHROMADB,
                                  MODELO_EMBEDDINGS)

    ruins = list(PASTA_LITERATURA.rglob("autor-desconhecido_*.pdf"))
    if not ruins:
        return "Metadados: todos os arquivos com nome correto"

    print(f"\nReprocessando {len(ruins)} arquivo(s) com metadados ruins...")
    try:
        from sentence_transformers import SentenceTransformer
        from src.conhecimento.processador_pdf import (
            extrair_metadados_pdf, gerar_nome_padronizado,
        )
        from src.conhecimento.indexador import indexar_pdf_unico
        import chromadb

        modelo  = SentenceTransformer(MODELO_EMBEDDINGS)
        client  = chromadb.PersistentClient(path=str(PASTA_CHROMADB))
        colecao = client.get_or_create_collection("literatura_pv")
        corrigidos = 0

        for pdf in ruins:
            print(f"   {pdf.name}")
            meta   = extrair_metadados_pdf(pdf)
            autor  = meta["autor"]
            titulo = meta["titulo"]
            ano    = meta["ano"]

            if autor == "autor-desconhecido":
                print(f"      LLM nao resolveu - mantido para revisao manual")
                continue

            nome_novo    = gerar_nome_padronizado(autor, titulo, ano)
            caminho_novo = pdf.parent / nome_novo

            if caminho_novo.exists() and caminho_novo != pdf:
                print(f"      Destino ja existe: {nome_novo} - pulando")
                continue

            res = colecao.get(where={"arquivo": pdf.name},
                              include=["metadatas"])
            ids_antigos = res.get("ids", [])
            if ids_antigos:
                colecao.delete(ids=ids_antigos)

            pdf.rename(caminho_novo)
            print(f"      -> {nome_novo}")

            res = indexar_pdf_unico(caminho_novo, modelo, PASTA_CHROMADB)
            print(f"      {res.get('n_chunks', 0)} chunks reindexados")
            corrigidos += 1

        return f"Metadados: {corrigidos} arquivo(s) corrigido(s)"
    except Exception as e:
        return f"Metadados: erro no reprocessamento - {e}"


# ============================================================
# REPROCESSAMENTO COMPLETO DA LITERATURA (sinal REPROCESSAR)
# ============================================================

def reprocessar_literatura() -> str:
    """
    Reprocessa todos os PDFs da literatura via LLM, renomeia e reindexa.
    Disparado pela presenca do arquivo REPROCESSAR na raiz.
    Operacao MUITO PESADA - so roda quando o sinal existe.
    """
    from tqdm import tqdm
    from sentence_transformers import SentenceTransformer
    from src.core.config import MODELO_EMBEDDINGS, PASTA_LITERATURA
    from src.conhecimento.processador_pdf import (
        extrair_metadados_pdf, gerar_nome_padronizado,
        classificar_tema, gerar_nota_obsidian, extrair_texto_pdf,
    )
    from src.conhecimento.indexador import indexar_pdf_unico
    import chromadb

    sinal = RAIZ_PROJETO / "REPROCESSAR"
    print("\nSinal REPROCESSAR detectado - iniciando reprocessamento completo...")

    try:
        modelo  = SentenceTransformer(MODELO_EMBEDDINGS)
        client  = chromadb.PersistentClient(path=str(PASTA_CHROMADB))
        colecao = client.get_or_create_collection("literatura_pv")

        pdfs       = sorted(PASTA_LITERATURA.rglob("*.pdf"))
        sucesso    = 0
        renomeados = 0
        falha      = 0
        relatorio  = ["REPROCESSAMENTO COMPLETO - Al IAdo PV", "=" * 60, ""]

        for pdf in tqdm(pdfs, desc="Reprocessando", unit="PDF"):
            try:
                meta   = extrair_metadados_pdf(pdf)
                autor  = meta["autor"]
                titulo = meta["titulo"]
                ano    = meta["ano"]

                nome_novo    = gerar_nome_padronizado(autor, titulo, ano)
                pasta_atual  = pdf.parent
                caminho_novo = pasta_atual / nome_novo

                res = colecao.get(where={"arquivo": pdf.name},
                                  include=["metadatas"])
                ids_antigos = res.get("ids", [])
                if ids_antigos:
                    colecao.delete(ids=ids_antigos)

                nome_tem_problema = (
                    "autor-desconhecido" in pdf.name or
                    pdf.name.startswith("p_") or
                    pdf.name.startswith("empresa_") or
                    pdf.name.startswith("data-set_") or
                    pdf.name.startswith("design_") or
                    pdf.name.startswith("for-facilities_") or
                    pdf.name.startswith("with-ua_") or
                    pdf.name.startswith("academic-editor_")
                )

                if nome_tem_problema and nome_novo != pdf.name:
                    if caminho_novo.exists():
                        caminho_novo = pasta_atual / nome_novo.replace(
                            ".pdf", "_v2.pdf")
                    pdf.rename(caminho_novo)
                    renomeados += 1
                else:
                    caminho_novo = pdf

                res    = indexar_pdf_unico(caminho_novo, modelo, PASTA_CHROMADB)
                chunks = res.get("n_chunks", 0)

                texto = extrair_texto_pdf(caminho_novo)
                tema  = classificar_tema(nome_novo, texto)
                gerar_nota_obsidian(nome_novo, autor, titulo, ano, tema, texto)

                relatorio.append(f"OK  {pdf.name[:48]} -> {nome_novo[:48]} "
                                  f"({chunks} chunks)")
                sucesso += 1
            except Exception as e:
                relatorio.append(f"ERRO {pdf.name[:48]} - {e}")
                falha += 1

        relatorio += ["", "=" * 60,
                      f"Sucesso   : {sucesso}",
                      f"Renomeados: {renomeados}",
                      f"Falha     : {falha}"]
        arquivo_rel = PASTA_RESULTADOS / "reprocessamento.txt"
        arquivo_rel.parent.mkdir(parents=True, exist_ok=True)
        arquivo_rel.write_text("\n".join(relatorio), encoding="utf-8")

        sinal.unlink()
        print("Arquivo REPROCESSAR removido - sinal consumido.")
        return (f"Reprocessamento: {sucesso} OK | "
                f"{renomeados} renomeados | {falha} falhas")
    except Exception as e:
        return f"Reprocessamento: erro - {e}"


# ============================================================
# ETAPAS DE ML - usadas pelos botoes do Streamlit (sob demanda)
# ============================================================

def etapa_eda() -> str:
    """Roda a analise exploratoria, se ainda nao foi feita."""
    if not eda_pendente():
        return "EDA: ja realizada"
    try:
        from src.ml.eda import executar_eda
        executar_eda()
        return "EDA: gerada com sucesso"
    except Exception as e:
        return f"EDA: erro - {e}"


def etapa_classificacao() -> str:
    """Roda a classificacao de ML, se ainda nao foi feita."""
    if not classificacao_pendente():
        return "Classificacao: ja realizada"
    try:
        from src.ml.classificador_pv import executar_classificacao
        executar_classificacao()
        return "Classificacao: gerada com sucesso"
    except Exception as e:
        return f"Classificacao: erro - {e}"


def etapa_features_ca() -> str:
    """Extrai features CA do dataset de Paderborn."""
    if not features_ca_pendente():
        return "Features CA: ja extraidas"
    try:
        from src.ml.features_ca import executar_features_ca
        ok = executar_features_ca()
        return "Features CA extraidas" if ok else "Features CA: falhou"
    except Exception as e:
        return f"Features CA: erro - {e}"


def etapa_autoencoder() -> str:
    """Treina o Autoencoder de deteccao de anomalias."""
    if not autoencoder_pendente():
        return "Autoencoder: ja treinado"
    if features_ca_pendente():
        return "Autoencoder: aguardando features CA"
    try:
        from src.ml.autoencoder import executar_autoencoder
        ok = executar_autoencoder()
        return "Autoencoder treinado" if ok else "Autoencoder: falhou"
    except Exception as e:
        return f"Autoencoder: erro - {e}"


def etapa_injecao_falhas() -> str:
    """Injeta falhas sinteticas fundamentadas no FMEA."""
    if not injecao_falhas_pendente():
        return "Injecao de falhas: ja realizada"
    if autoencoder_pendente():
        return "Injecao de falhas: aguardando Autoencoder"
    try:
        from src.ml.injecao_falhas import executar_injecao_falhas
        ok = executar_injecao_falhas()
        return "Injecao de falhas concluida" if ok else "Injecao de falhas: falhou"
    except Exception as e:
        return f"Injecao de falhas: erro - {e}"


def etapa_validacao_ml() -> str:
    """Validacao formal: AUC, F1, Recall por tipo de falha."""
    if not validacao_pendente():
        return "Validacao ML: ja realizada"
    if injecao_falhas_pendente():
        return "Validacao ML: aguardando injecao de falhas"
    try:
        from src.ml.validacao import executar_validacao
        ok = executar_validacao()
        return "Validacao ML concluida" if ok else "Validacao ML: falhou"
    except Exception as e:
        return f"Validacao ML: erro - {e}"


def etapa_rul_weibull() -> str:
    """Estimativa de RUL com Analise de Weibull."""
    if not rul_weibull_pendente():
        return "RUL/Weibull: ja calculado"
    if validacao_pendente():
        return "RUL/Weibull: aguardando validacao ML"
    try:
        from src.ml.rul_weibull import executar_rul_weibull
        ok = executar_rul_weibull()
        return "RUL/Weibull calculado" if ok else "RUL/Weibull: falhou"
    except Exception as e:
        return f"RUL/Weibull: erro - {e}"


# ============================================================
# ORQUESTRACAO PRINCIPAL - INICIALIZACAO LEVE
# ============================================================

def executar_pipeline(modelo_embeddings) -> list:
    """
    Executado pelo app.py na inicializacao.

    CONTEM APENAS TRABALHO LEVE E RAPIDO:
      - reprocessamento completo, SE o sinal REPROCESSAR existir
      - indexacao de PDFs novos (rapida)

    NAO faz: consolidacao de memoria, reprocessamento de metadados
    via LLM, nem pipeline de ML. Essas operacoes pesadas rodam
    sob demanda (agendador do watcher ou botoes do Streamlit),
    para que o app sempre abra em segundos.

    Retorna lista de mensagens de status.
    """
    relatorio = []

    # Reprocessamento completo - so se o sinal existir (acao explicita)
    if ha_sinal_reprocessamento():
        relatorio.append(reprocessar_literatura())

    # Indexacao de PDFs novos - operacao leve
    relatorio.append(etapa_indexar_pdfs(modelo_embeddings))

    return relatorio


if __name__ == "__main__":
    print("=" * 60)
    print("  AL IADO PV - ORQUESTRADOR (teste de estado)")
    print("=" * 60)
    print(f"\nSinal REPROCESSAR         : {ha_sinal_reprocessamento()}")
    print(f"PDFs novos pendentes      : {ha_pdfs_novos()}")
    print(f"Sessoes para consolidar   : {ha_sessoes_para_consolidar()}")
    print(f"Arquivos com nome ruim    : {ha_arquivos_com_nome_ruim()}")
    print(f"EDA pendente              : {eda_pendente()}")
    print(f"Classificacao pendente    : {classificacao_pendente()}")
    print(f"Features CA pendente      : {features_ca_pendente()}")
    print(f"Autoencoder pendente      : {autoencoder_pendente()}")
    print(f"Injecao de falhas pendente: {injecao_falhas_pendente()}")
    print(f"Validacao ML pendente     : {validacao_pendente()}")
    print(f"RUL/Weibull pendente      : {rul_weibull_pendente()}")
    print("=" * 60)