"""
indexador.py — Al IAdo PV

Indexador seguro para literatura e sessões.

Correções principais desta versão:
- controle de duplicidade por SHA256 do PDF;
- IDs determinísticos por hash + chunk;
- uso de upsert em lotes;
- chunking de literatura menos granular;
- remoção da combinação problemática:
    chunking fixo + chunking por seções + tabelas;
- extração de tabelas opcional via variável de ambiente.

Execute pela raiz do projeto:
    python src/conhecimento/indexador.py
"""

import hashlib
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import chromadb
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer

from src.core.utils import parsear_nome_arquivo
from src.core.config import (
    PASTA_LITERATURA,
    PASTA_CHROMADB,
    NOME_COLECAO,
    NOME_COLECAO_SESSOES,
    MODELO_EMBEDDINGS,
    TAMANHO_CHUNK,
    SOBREPOSICAO,
    TAMANHO_LOTE,
)

# ============================================================
# PARÂMETROS ESPECÍFICOS PARA LITERATURA
# ============================================================

# O valor antigo de 500 caracteres gerava uma coleção excessivamente granular.
# Para RAG acadêmico, 1600–2200 caracteres costuma ser mais equilibrado.
TAMANHO_CHUNK_LITERATURA = int(os.getenv("TAMANHO_CHUNK_LITERATURA", "1800"))
SOBREPOSICAO_LITERATURA = int(os.getenv("SOBREPOSICAO_LITERATURA", "200"))

# A extração de tabelas com pdfplumber é útil, mas cara e pode aumentar a base.
# Por padrão fica desligada. Para ativar:
# PowerShell:
#   $env:EXTRAIR_TABELAS_LITERATURA="1"
# CMD:
#   set EXTRAIR_TABELAS_LITERATURA=1
EXTRAIR_TABELAS_LITERATURA = os.getenv("EXTRAIR_TABELAS_LITERATURA", "0") == "1"


# ============================================================
# UTILITÁRIOS
# ============================================================

def calcular_hash_arquivo(caminho: Path) -> str:
    """Calcula SHA256 do arquivo, usado como identidade estável do PDF."""
    sha = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(1024 * 1024), b""):
            sha.update(bloco)
    return sha.hexdigest()


def documento_ja_indexado(colecao, arquivo_hash: str) -> bool:
    """Retorna True se o conteúdo exato do PDF já estiver indexado."""
    try:
        res = colecao.get(where={"arquivo_hash": arquivo_hash}, limit=1)
        return bool(res.get("ids"))
    except Exception:
        return False


def remover_documento_antigo(colecao, nome_arquivo: str | None = None, arquivo_hash: str | None = None) -> int:
    """
    Remove chunks antigos por nome e/ou hash.

    Observação:
    - por nome: remove resíduos de versões antigas sem hash;
    - por hash: remove resíduos do mesmo conteúdo.
    """
    removidos = 0
    filtros = []

    if nome_arquivo:
        filtros.append({"arquivo": nome_arquivo})

    if arquivo_hash:
        filtros.append({"arquivo_hash": arquivo_hash})

    for where in filtros:
        try:
            res = colecao.get(where=where)
            ids = res.get("ids", []) or []
            if ids:
                for inicio in range(0, len(ids), TAMANHO_LOTE):
                    fim = inicio + TAMANHO_LOTE
                    colecao.delete(ids=ids[inicio:fim])
                removidos += len(ids)
        except Exception:
            # Não interrompe indexação por resíduo antigo problemático.
            pass

    return removidos


def upsert_em_lotes(colecao, ids, embeddings, documents, metadados, tamanho_lote: int = 500) -> None:
    """Executa upsert em lotes para evitar limites internos do ChromaDB/SQLite."""
    total = len(ids)

    for inicio in range(0, total, tamanho_lote):
        fim = min(inicio + tamanho_lote, total)
        colecao.upsert(
            ids=ids[inicio:fim],
            embeddings=embeddings[inicio:fim],
            documents=documents[inicio:fim],
            metadatas=metadados[inicio:fim],
        )


# ============================================================
# EXTRAÇÃO E CHUNKING DE PDF
# ============================================================

def ler_pdf(caminho_pdf: Path) -> str:
    """Extrai texto do PDF usando pypdf."""
    try:
        reader = PdfReader(str(caminho_pdf))
        partes = []

        for pagina in reader.pages:
            texto_pagina = pagina.extract_text()
            if texto_pagina:
                partes.append(texto_pagina)

        return "\n\n".join(partes).strip()

    except Exception as e:
        print(f"  ⚠️  Erro ao ler {caminho_pdf.name}: {e}")
        return ""


def normalizar_texto_pdf(texto: str) -> str:
    """
    Normaliza texto extraído de PDF.

    A intenção é reduzir ruído sem destruir fórmulas, siglas ou símbolos técnicos.
    """
    if not texto:
        return ""

    texto = texto.replace("\x00", " ")

    # Une palavras quebradas por hifenização no fim da linha:
    # confiabili-\ndade -> confiabilidade
    texto = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", texto)

    # Normaliza quebras excessivas de linha.
    texto = re.sub(r"[ \t]+", " ", texto)
    texto = re.sub(r"\n{3,}", "\n\n", texto)

    # Remove espaços antes de pontuação comum.
    texto = re.sub(r"\s+([,.;:!?])", r"\1", texto)

    return texto.strip()


def _melhor_ponto_de_corte(texto: str, inicio: int, limite: int, tamanho_minimo: int) -> int:
    """
    Escolhe um corte próximo do limite, preferindo fim de frase/parágrafo.
    Evita gerar chunks cortados no meio de sentenças quando possível.
    """
    n = len(texto)

    if limite >= n:
        return n

    janela_inicio = max(inicio + tamanho_minimo, limite - 500)
    trecho = texto[janela_inicio:limite]

    # Preferência 1: fim de parágrafo.
    pos = trecho.rfind("\n\n")
    if pos != -1:
        return janela_inicio + pos

    # Preferência 2: fim de frase.
    candidatos = [trecho.rfind("."), trecho.rfind(";"), trecho.rfind(":"), trecho.rfind("?"), trecho.rfind("!")]
    pos = max(candidatos)
    if pos != -1:
        return janela_inicio + pos + 1

    # Preferência 3: último espaço.
    pos = trecho.rfind(" ")
    if pos != -1:
        return janela_inicio + pos

    return limite


def dividir_em_chunks(texto: str, tamanho: int, sobreposicao: int) -> list[str]:
    """
    Divide texto em chunks por caracteres, com corte em ponto semântico quando possível.

    Esta função continua existindo com a mesma assinatura para preservar compatibilidade
    com indexação de sessões e outros módulos.
    """
    texto = normalizar_texto_pdf(texto)

    if not texto:
        return []

    tamanho = max(int(tamanho), 300)
    sobreposicao = max(0, min(int(sobreposicao), tamanho // 3))
    tamanho_minimo = max(250, tamanho // 2)

    chunks = []
    inicio = 0
    n = len(texto)

    while inicio < n:
        limite = min(inicio + tamanho, n)
        corte = _melhor_ponto_de_corte(texto, inicio, limite, tamanho_minimo)

        if corte <= inicio:
            corte = limite

        chunk = texto[inicio:corte].strip()

        if len(chunk) >= 80:
            chunks.append(chunk)

        if corte >= n:
            break

        novo_inicio = max(corte - sobreposicao, inicio + 1)

        # Evita começar no meio de espaço/quebra.
        while novo_inicio < n and texto[novo_inicio].isspace():
            novo_inicio += 1

        inicio = novo_inicio

    return chunks


def extrair_tabelas_pdf(caminho_pdf: Path, metadados_doc: dict) -> list[str]:
    """
    Extrai tabelas do PDF como chunks Markdown estruturados.

    Esta rotina é opcional porque aumenta tempo de indexação e tamanho da base.
    Ative apenas quando tabelas forem essenciais para a busca.
    """
    chunks_tabelas = []

    if not EXTRAIR_TABELAS_LITERATURA:
        return chunks_tabelas

    citacao = metadados_doc.get("citacao", caminho_pdf.name)

    try:
        import pdfplumber

        with pdfplumber.open(str(caminho_pdf)) as pdf:
            for num_pag, pagina in enumerate(pdf.pages, 1):
                tabelas = pagina.extract_tables()
                if not tabelas:
                    continue

                for num_tab, tabela in enumerate(tabelas, 1):
                    if not tabela or len(tabela) < 2:
                        continue

                    linhas_validas = [
                        linha for linha in tabela
                        if linha and any(cel and str(cel).strip() for cel in linha)
                    ]

                    if len(linhas_validas) < 2:
                        continue

                    def limpar_celula(cel):
                        if cel is None:
                            return ""
                        return str(cel).replace("\n", " ").strip()

                    cabecalho = linhas_validas[0]
                    corpo = linhas_validas[1:]
                    n_cols = len(cabecalho)

                    md = f"[TABELA — {citacao} — Página {num_pag}, Tabela {num_tab}]\n"
                    md += "| " + " | ".join(limpar_celula(c) for c in cabecalho) + " |\n"
                    md += "| " + " | ".join("---" for _ in cabecalho) + " |\n"

                    for linha in corpo:
                        linha_pad = list(linha) + [""] * max(0, n_cols - len(linha))
                        md += "| " + " | ".join(limpar_celula(c) for c in linha_pad[:n_cols]) + " |\n"

                    if len(md) >= 150:
                        chunks_tabelas.append(md.strip())

    except ImportError:
        print("  ⚠️  pdfplumber não instalado; tabelas ignoradas.")
    except Exception as e:
        print(f"  ⚠️  Erro ao extrair tabelas de {caminho_pdf.name}: {e}")

    return chunks_tabelas


def remover_chunks_duplicados(chunks: list[str]) -> list[str]:
    """
    Remove chunks textual ou quase textualmente idênticos.
    """
    vistos = set()
    unicos = []

    for chunk in chunks:
        normalizado = " ".join(chunk.split()).strip()
        if not normalizado:
            continue

        chave = hashlib.sha1(normalizado.lower().encode("utf-8", errors="ignore")).hexdigest()

        if chave in vistos:
            continue

        vistos.add(chave)
        unicos.append(chunk.strip())

    return unicos


# ============================================================
# INDEXAÇÃO DE LITERATURA
# ============================================================

def indexar_pdf_unico(caminho_pdf: Path, modelo_embeddings, pasta_chromadb: Path) -> dict:
    """
    Indexa um único PDF no ChromaDB com proteção contra duplicidade.

    Estratégia:
    1. calcula SHA256 do arquivo;
    2. se o mesmo conteúdo já estiver indexado, pula;
    3. remove resíduos antigos por nome/hash;
    4. gera chunks apenas por uma estratégia principal;
    5. opcionalmente adiciona chunks de tabelas;
    6. usa IDs determinísticos e upsert.
    """
    resultado = {
        "sucesso": False,
        "nome_arquivo": caminho_pdf.name,
        "n_chunks": 0,
        "pulou": False,
        "motivo": "",
        "erro": None,
    }

    try:
        arquivo_hash = calcular_hash_arquivo(caminho_pdf)

        client = chromadb.PersistentClient(path=str(pasta_chromadb))
        colecao = client.get_or_create_collection(
            name=NOME_COLECAO,
            metadata={"hnsw:space": "cosine"},
        )

        if documento_ja_indexado(colecao, arquivo_hash):
            resultado["sucesso"] = True
            resultado["pulou"] = True
            resultado["motivo"] = "PDF já indexado pelo mesmo hash SHA256."
            try:
                resultado["n_chunks"] = len(colecao.get(where={"arquivo_hash": arquivo_hash}).get("ids", []))
            except Exception:
                resultado["n_chunks"] = 0
            return resultado

        texto = ler_pdf(caminho_pdf)

        if not texto:
            resultado["erro"] = "Não foi possível extrair texto do PDF."
            return resultado

        info_arquivo = parsear_nome_arquivo(caminho_pdf.name)

        # Estratégia principal: um único pipeline de chunking.
        chunks = dividir_em_chunks(
            texto,
            TAMANHO_CHUNK_LITERATURA,
            SOBREPOSICAO_LITERATURA,
        )

        # Tabelas são opcionais.
        chunks_tabelas = extrair_tabelas_pdf(caminho_pdf, info_arquivo)

        chunks = remover_chunks_duplicados(chunks + chunks_tabelas)

        if not chunks:
            resultado["erro"] = "Nenhum chunk gerado."
            return resultado

        removidos = remover_documento_antigo(
            colecao,
            nome_arquivo=caminho_pdf.name,
            arquivo_hash=arquivo_hash,
        )

        if removidos:
            print(f"  Removidos {removidos} chunks antigos de {caminho_pdf.name}")

        embeddings = modelo_embeddings.encode(chunks).tolist()

        nome_pasta = caminho_pdf.parent.name
        ids = [f"{arquivo_hash}__chunk_{j:05d}" for j in range(len(chunks))]

        metadados = [
            {
                "arquivo": caminho_pdf.name,
                "arquivo_hash": arquivo_hash,
                "pasta": nome_pasta,
                "chunk_index": j,
                "total_chunks": len(chunks),
                "autor": info_arquivo.get("autor", ""),
                "titulo": info_arquivo.get("titulo", ""),
                "ano": info_arquivo.get("ano", ""),
                "citacao": info_arquivo.get("citacao", caminho_pdf.name),
            }
            for j in range(len(chunks))
        ]

        upsert_em_lotes(
            colecao=colecao,
            ids=ids,
            embeddings=embeddings,
            documents=chunks,
            metadados=metadados,
            tamanho_lote=TAMANHO_LOTE,
        )

        resultado["sucesso"] = True
        resultado["n_chunks"] = len(chunks)
        return resultado

    except Exception as e:
        resultado["erro"] = str(e)
        return resultado


def indexar_literatura() -> None:
    """Indexa todos os PDFs da pasta de literatura."""
    print("=" * 72)
    print("AL IADO PV — INDEXADOR SEGURO DE LITERATURA")
    print("=" * 72)

    if not PASTA_LITERATURA.exists():
        print(f"Pasta não encontrada: {PASTA_LITERATURA}")
        return

    pdfs = sorted(PASTA_LITERATURA.rglob("*.pdf"))

    if not pdfs:
        print(f"Nenhum PDF encontrado em: {PASTA_LITERATURA}")
        return

    print(f"PDFs encontrados: {len(pdfs)}")
    print(f"Modelo de embeddings: {MODELO_EMBEDDINGS}")
    print(f"Chunk literatura: {TAMANHO_CHUNK_LITERATURA}")
    print(f"Sobreposição literatura: {SOBREPOSICAO_LITERATURA}")
    print(f"Extração de tabelas: {'ativada' if EXTRAIR_TABELAS_LITERATURA else 'desativada'}")

    modelo = SentenceTransformer(MODELO_EMBEDDINGS)

    total_chunks = 0
    pdfs_indexados = 0
    pdfs_pulados = 0
    pdfs_com_erro = 0

    for i, caminho_pdf in enumerate(pdfs, 1):
        print(f"[{i}/{len(pdfs)}] {caminho_pdf.name}")
        resultado = indexar_pdf_unico(caminho_pdf, modelo, PASTA_CHROMADB)

        if not resultado.get("sucesso"):
            pdfs_com_erro += 1
            print(f"  ERRO: {resultado.get('erro')}")
            continue

        if resultado.get("pulou"):
            pdfs_pulados += 1
            print(f"  SKIP: {resultado.get('motivo')}")
            continue

        n_chunks = int(resultado.get("n_chunks", 0))
        total_chunks += n_chunks
        pdfs_indexados += 1
        print(f"  OK: {n_chunks} chunks")

    print("=" * 72)
    print("INDEXAÇÃO CONCLUÍDA")
    print(f"PDFs indexados : {pdfs_indexados}")
    print(f"PDFs pulados   : {pdfs_pulados}")
    print(f"PDFs com erro  : {pdfs_com_erro}")
    print(f"Chunks novos   : {total_chunks}")
    print("=" * 72)


# ============================================================
# INDEXAÇÃO DE SESSÕES
# ============================================================

def indexar_sessao(caminho_md: Path, modelo_embeddings, pasta_chromadb: Path) -> int:
    """
    Indexa uma sessão salva (.md) na coleção de sessões do ChromaDB.

    Mantém a assinatura original para compatibilidade com o restante do sistema.
    """
    if not caminho_md.exists():
        print(f"  ⚠️  Arquivo não encontrado: {caminho_md}")
        return 0

    texto = caminho_md.read_text(encoding="utf-8", errors="ignore")

    if not texto.strip():
        return 0

    linhas_filtradas = []
    for linha in texto.split("\n"):
        if any(termo in linha.lower() for termo in [
            "rate limit", "429", "resource_exhausted",
            "quota", "error code", "❌ erro",
        ]):
            continue
        linhas_filtradas.append(linha)

    texto = "\n".join(linhas_filtradas)

    chunks = dividir_em_chunks(texto, TAMANHO_CHUNK, SOBREPOSICAO)

    if not chunks:
        return 0

    client = chromadb.PersistentClient(path=str(pasta_chromadb))
    colecao_sessoes = client.get_or_create_collection(
        name=NOME_COLECAO_SESSOES,
        metadata={"hnsw:space": "cosine"},
    )

    embeddings = modelo_embeddings.encode(chunks).tolist()

    nome_arquivo = caminho_md.name
    ids = [f"{nome_arquivo}__chunk_{j:05d}" for j in range(len(chunks))]

    data_sessao = caminho_md.stem[:10]

    metadados = [
        {
            "arquivo": nome_arquivo,
            "tipo": "sessao",
            "data": data_sessao,
            "chunk_index": j,
            "total_chunks": len(chunks),
        }
        for j in range(len(chunks))
    ]

    upsert_em_lotes(
        colecao=colecao_sessoes,
        ids=ids,
        embeddings=embeddings,
        documents=chunks,
        metadados=metadados,
        tamanho_lote=TAMANHO_LOTE,
    )

    return len(chunks)


if __name__ == "__main__":
    indexar_literatura()
