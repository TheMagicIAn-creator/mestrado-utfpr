"""
app.py - Al IAdo PV
Interface web com Streamlit.

A inicializacao e leve: o orquestrador apenas indexa PDFs novos.
Operacoes pesadas (consolidar memoria, reprocessar metadados,
pipeline de ML) sao acionadas por botoes, nunca no carregamento.

Como executar:
  streamlit run app.py

Autor: Rodolfo Torres (UTFPR)
"""

from watcher import iniciar_em_background
import sys
from pathlib import Path
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))

import streamlit as st
from langchain_core.messages import HumanMessage

# ============================================================
# CONFIGURACAO DA PAGINA
# ============================================================

st.set_page_config(
    page_title = "Al IAdo PV",
    page_icon  = "PV",
    layout     = "wide",
    initial_sidebar_state = "expanded"
)

RAIZ     = Path(__file__).parent
PASTA_AE = RAIZ / "resultados" / "autoencoder"

# ── Mapa de artefatos por etapa (ordem = dependencias) ───────
ORDEM_ETAPAS_ML = ["features_ca", "autoencoder", "injecao_falhas",
                   "validacao", "rul_weibull"]

ARTEFATOS_ML = {
    "features_ca": [
        "dados/processados/features_paderborn.parquet",
        "dados/processados/features_paderborn_stats.csv",
    ],
    "autoencoder": [
        "resultados/autoencoder/modelo_autoencoder.pt",
        "resultados/autoencoder/scaler.pkl",
        "resultados/autoencoder/limiar.json",
        "resultados/autoencoder/curva_treino.png",
        "resultados/autoencoder/distribuicao_erro.png",
        "resultados/autoencoder/erro_temporal.png",
    ],
    "injecao_falhas": [
        "resultados/autoencoder/injecao_falhas_resultados.png",
        "resultados/autoencoder/injecao_falhas_comparacao.png",
        "resultados/autoencoder/injecao_falhas_report.json",
    ],
    "validacao": [
        "resultados/autoencoder/validacao_roc.png",
        "resultados/autoencoder/validacao_matriz.png",
        "resultados/autoencoder/validacao_metricas.png",
        "resultados/autoencoder/validacao_tabela.csv",
        "resultados/autoencoder/validacao_report.json",
    ],
    "rul_weibull": [
        "resultados/autoencoder/weibull_ttf.png",
        "resultados/autoencoder/weibull_confiabilidade.png",
        "resultados/autoencoder/weibull_rul.png",
        "resultados/autoencoder/weibull_results.json",
    ],
}

NOMES_ETAPAS = {
    "features_ca"    : "Features CA",
    "autoencoder"    : "Autoencoder",
    "injecao_falhas" : "Injecao de Falhas",
    "validacao"      : "Validacao Formal",
    "rul_weibull"    : "RUL / Weibull",
}


def _limpar_artefatos(etapa_inicial: str):
    """Apaga artefatos da etapa e de todas as que dependem dela."""
    idx = ORDEM_ETAPAS_ML.index(etapa_inicial)
    for etapa in ORDEM_ETAPAS_ML[idx:]:
        for rel in ARTEFATOS_ML[etapa]:
            arq = RAIZ / rel
            if arq.exists():
                arq.unlink()


def _regenerar(etapa_inicial: str, status=None) -> list:
    """
    Apaga artefatos da etapa (e downstream) e re-executa diretamente
    os modulos de ML em ordem estrita. Para no primeiro erro.
    """
    _limpar_artefatos(etapa_inicial)

    from src.ml.features_ca    import executar_features_ca
    from src.ml.autoencoder    import executar_autoencoder
    from src.ml.injecao_falhas import executar_injecao_falhas
    from src.ml.validacao      import executar_validacao
    from src.ml.rul_weibull    import executar_rul_weibull

    funcs = {
        "features_ca"    : ("Features CA",       executar_features_ca),
        "autoencoder"    : ("Autoencoder",       executar_autoencoder),
        "injecao_falhas" : ("Injecao de Falhas", executar_injecao_falhas),
        "validacao"      : ("Validacao Formal",  executar_validacao),
        "rul_weibull"    : ("RUL / Weibull",     executar_rul_weibull),
    }

    idx        = ORDEM_ETAPAS_ML.index(etapa_inicial)
    resultados = []
    for etapa in ORDEM_ETAPAS_ML[idx:]:
        nome, func = funcs[etapa]
        if status:
            status.write(f"Executando: {nome}...")
        try:
            ok = func()
            if ok:
                msg = f"OK - {nome} regenerado"
                resultados.append(msg)
                if status:
                    status.write(msg)
            else:
                msg = f"FALHA - {nome} retornou erro"
                resultados.append(msg)
                if status:
                    status.write(msg)
                break
        except Exception as e:
            msg = f"ERRO - {nome}: {e}"
            resultados.append(msg)
            if status:
                status.write(msg)
            break
    return resultados


# ============================================================
# CARREGAMENTO DOS COMPONENTES (cache)
# ============================================================

@st.cache_resource
def carregar_base():
    """
    Carrega embeddings e ChromaDB uma unica vez.
    Executa o orquestrador (apenas trabalho leve).
    """
    from sentence_transformers import SentenceTransformer
    import chromadb
    from src.conhecimento.agente import carregar_perfil
    from src.core.config import (
        MODELO_EMBEDDINGS, PASTA_CHROMADB,
        NOME_COLECAO, NOME_COLECAO_SESSOES
    )

    with st.spinner("Carregando modelo de embeddings..."):
        modelo = SentenceTransformer(MODELO_EMBEDDINGS)
        try:
            iniciar_em_background(modelo)
        except Exception:
            pass

    relatorio = []
    with st.spinner("Verificando estado do projeto..."):
        try:
            from src.orquestrador import executar_pipeline
            relatorio = executar_pipeline(modelo)
            print("=" * 60)
            print("  ORQUESTRADOR - RELATORIO DE INICIALIZACAO")
            print("=" * 60)
            for linha in relatorio:
                print(f"  {linha}")
            print("=" * 60)
        except Exception as e:
            print(f"[Orquestrador] Erro: {e}")

    with st.spinner("Conectando ao ChromaDB..."):
        client          = chromadb.PersistentClient(path=str(PASTA_CHROMADB))
        colecao         = client.get_or_create_collection(name=NOME_COLECAO)
        colecao_sessoes = client.get_or_create_collection(name=NOME_COLECAO_SESSOES)

    perfil = carregar_perfil()
    return perfil, modelo, colecao, colecao_sessoes, relatorio


# ============================================================
# FEEDBACK DO ORQUESTRADOR
# ============================================================

def mostrar_novidades_orquestrador(relatorio: list):
    """Exibe aviso apenas quando algo novo foi processado."""
    termos_inertes = ["nenhum pendente", "ja realizada", "ja extraidas",
                      "ja treinado", "ja calculado"]

    def para_texto(item):
        if isinstance(item, dict):
            if item.get("executou"):
                return f"Memoria consolidada ({item.get('motivo', '')})"
            if item.get("erro"):
                return f"Erro na consolidacao: {item['erro']}"
            return ""
        return str(item) if item else ""

    linhas = [para_texto(i) for i in relatorio]
    novidades = [l for l in linhas
                 if l and not any(t in l.lower() for t in termos_inertes)]

    if novidades:
        with st.expander("O sistema processou novidades", expanded=True):
            for linha in novidades:
                if "erro" in linha.lower():
                    st.warning(linha)
                else:
                    st.success(linha)


# ============================================================
# STREAMING
# ============================================================

def stream_resposta(prompt: str, llm):
    """Generator de streaming do LLM para o Streamlit."""
    for chunk in llm.stream([HumanMessage(content=prompt)]):
        yield chunk.content


# ============================================================
# SIDEBAR
# ============================================================

def _processar_upload(arquivo_pdf):
    """Salva o PDF em novos_pdfs/ para o watcher processar."""
    pasta_entrada = RAIZ / "novos_pdfs"
    pasta_entrada.mkdir(exist_ok=True)
    destino = pasta_entrada / arquivo_pdf.name
    with open(destino, "wb") as f:
        f.write(arquivo_pdf.getbuffer())
    st.success(f"PDF enviado: {arquivo_pdf.name}\n\n"
               f"O watcher ira processar automaticamente.")


def renderizar_sidebar(modelo, colecao, colecao_sessoes):
    """Renderiza o painel lateral com controles e estatisticas."""
    with st.sidebar:
        st.title("Al IAdo PV")
        st.caption("Assistente de Mestrado - UTFPR")
        st.divider()

        # ── Provedor de LLM ──────────────────────────────────
        st.subheader("Provedor de LLM")
        from src.conhecimento.provedores import PROVEDORES
        opcoes = {info["nome"]: chave for chave, info in PROVEDORES.items()}

        escolha_label = st.selectbox(
            "Modelo:", options=list(opcoes.keys()),
            index=0, key="provedor_select"
        )
        escolha = opcoes[escolha_label]
        info    = PROVEDORES[escolha]
        st.caption(f"Limite: {info['limite']}")

        if st.button("Conectar provedor", use_container_width=True):
            try:
                from src.conhecimento.provedores import inicializar_provedor
                with st.spinner(f"Conectando ao {info['nome']}..."):
                    llm, nome = inicializar_provedor(escolha)
                st.session_state.llm           = llm
                st.session_state.nome_provedor = nome
                st.success(f"{nome} conectado")
            except Exception as e:
                st.error(f"Erro: {e}")

        st.divider()

        # ── Estatisticas ─────────────────────────────────────
        st.subheader("Base de Conhecimento")
        col1, col2 = st.columns(2)
        col1.metric("Literatura", f"{colecao.count()}", "chunks")
        col2.metric("Sessoes",    f"{colecao_sessoes.count()}", "chunks")

        st.divider()

        # ── Acoes ────────────────────────────────────────────
        st.subheader("Acoes")
        if st.button("Limpar conversa", use_container_width=True):
            st.session_state.mensagens = []
            st.rerun()

        st.divider()

        # ── Upload de PDF ────────────────────────────────────
        st.subheader("Adicionar PDF")
        arquivo_pdf = st.file_uploader("Selecione o PDF:", type=["pdf"],
                                        key="pdf_uploader")
        if arquivo_pdf is not None:
            if st.button("Processar PDF", use_container_width=True):
                _processar_upload(arquivo_pdf)

        st.divider()

        # ── Manutencao (operacoes pesadas sob demanda) ───────
        with st.expander("Manutencao do sistema"):
            st.caption("Operacoes pesadas - rode quando necessario.")

            if st.button("Consolidar memoria agora",
                          use_container_width=True):
                with st.spinner("Consolidando memoria das sessoes..."):
                    try:
                        from src.conhecimento.consolidar_memoria import consolidar
                        ok = consolidar(forcar=True)
                        if ok:
                            st.success("Memoria consolidada")
                        else:
                            st.info("Nada a consolidar (sessoes insuficientes)")
                    except Exception as e:
                        st.error(f"Erro: {e}")

            if st.button("Reprocessar metadados ruins",
                          use_container_width=True):
                with st.spinner("Reprocessando PDFs com nome ruim..."):
                    try:
                        from src.orquestrador import reprocessar_metadados_ruins
                        msg = reprocessar_metadados_ruins()
                        st.success(msg)
                    except Exception as e:
                        st.error(f"Erro: {e}")

        nome_ativo = st.session_state.get("nome_provedor", "Nenhum")
        st.caption(f"Provedor ativo: {nome_ativo}")


# ============================================================
# SALVAR SESSAO
# ============================================================

def salvar_sessao_streamlit(pergunta: str, resposta: str,
                             n: int, modelo_embeddings):
    """Cria o arquivo de sessao na primeira interacao e adiciona nas seguintes."""
    from src.core.config import PASTA_CHROMADB
    pasta_sessoes = RAIZ / "notas" / "sessoes"
    pasta_sessoes.mkdir(parents=True, exist_ok=True)

    if st.session_state.caminho_sessao is None:
        agora = datetime.now()
        nome  = agora.strftime("%Y-%m-%d_%H-%M") + "_sessao_web.md"
        caminho   = pasta_sessoes / nome
        data_fmt  = agora.strftime("%d/%m/%Y as %H:%M")
        cabecalho = (f"---\ndata: {agora.strftime('%Y-%m-%d')}\n"
                     f"hora: {agora.strftime('%H:%M')}\ntipo: sessao-web\n"
                     f"tags: [al-iado-pv, sessao, streamlit, mestrado]\n"
                     f"---\n\n# Sessao Web Al IAdo PV - {data_fmt}\n\n")
        caminho.write_text(cabecalho, encoding="utf-8")
        st.session_state.caminho_sessao = caminho

    caminho = st.session_state.caminho_sessao
    bloco   = (f"---\n\n## Interacao {n}\n\n"
               f"**Voce:** {pergunta}\n\n"
               f"**Al IAdo PV:**\n\n{resposta}\n\n")
    with open(caminho, "a", encoding="utf-8") as f:
        f.write(bloco)

    try:
        from src.conhecimento.indexador import indexar_sessao
        indexar_sessao(caminho, modelo_embeddings, PASTA_CHROMADB)
    except Exception:
        pass


# ============================================================
# ABA - RESULTADOS ML
# ============================================================

def renderizar_aba_ml():
    """Dashboard dos resultados da Fase 5."""
    import json
    import pandas as pd

    st.header("Fase 5 - Pipeline de Machine Learning")
    st.caption("Analise preditiva de falhas em componentes CA do inversor")

    from src.orquestrador import (
        features_ca_pendente, autoencoder_pendente,
        injecao_falhas_pendente, validacao_pendente, rul_weibull_pendente
    )

    etapas = {
        "Features CA"       : not features_ca_pendente(),
        "Autoencoder"       : not autoencoder_pendente(),
        "Injecao de Falhas" : not injecao_falhas_pendente(),
        "Validacao"         : not validacao_pendente(),
        "RUL / Weibull"     : not rul_weibull_pendente(),
    }

    cols = st.columns(5)
    for col, (nome, pronto) in zip(cols, etapas.items()):
        with col:
            if pronto:
                st.success(nome)
            else:
                st.error(f"{nome} (pendente)")

    st.divider()

    # ── Painel de regeneracao ────────────────────────────────
    with st.expander("Regenerar resultados", expanded=False):
        st.caption("Apaga os resultados salvos e gera novamente. "
                   "Regenerar uma etapa tambem refaz as que dependem dela.")

        col1, col2 = st.columns(2)

        with col1:
            st.markdown("**Pipeline completo**")
            if st.button("Regenerar tudo", use_container_width=True,
                         type="primary", key="btn_regen_tudo"):
                with st.status("Regenerando pipeline ML completo...",
                               expanded=True) as status:
                    resultados = _regenerar("features_ca", status)
                    ok = all("OK" in r for r in resultados)
                    status.update(
                        label=("Pipeline regenerado" if ok
                               else "Regeneracao interrompida por erro"),
                        state="complete" if ok else "error"
                    )
                st.rerun()

        with col2:
            st.markdown("**A partir de uma etapa**")
            etapa_sel = st.selectbox(
                "Etapa inicial:", options=ORDEM_ETAPAS_ML,
                format_func=lambda e: NOMES_ETAPAS[e],
                key="regen_select", label_visibility="collapsed"
            )
            if st.button("Regenerar a partir desta etapa",
                         use_container_width=True, key="btn_regen_etapa"):
                with st.status(f"Regenerando a partir de "
                               f"{NOMES_ETAPAS[etapa_sel]}...",
                               expanded=True) as status:
                    resultados = _regenerar(etapa_sel, status)
                    ok = all("OK" in r for r in resultados)
                    status.update(
                        label=("Regeneracao concluida" if ok
                               else "Regeneracao interrompida por erro"),
                        state="complete" if ok else "error"
                    )
                st.rerun()

        st.divider()
        st.markdown("**Sincronizar com o agente**")
        st.caption("Indexa os resultados na base de conhecimento "
                   "para o agente discuti-los no chat.")
        if st.button("Indexar resultados para o agente",
                     use_container_width=True, key="btn_indexar_ml"):
            with st.spinner("Indexando resultados..."):
                try:
                    import subprocess
                    subprocess.run([sys.executable, "indexar_resultados_ml.py"],
                                   check=True, cwd=str(RAIZ))
                    st.success("Resultados indexados - o agente ja pode discuti-los")
                except Exception as e:
                    st.error(f"Erro: {e}")

    st.divider()

    # ── Autoencoder ──────────────────────────────────────────
    with st.expander("Autoencoder - Modelagem de Normalidade", expanded=True):
        arq = PASTA_AE / "limiar.json"
        if arq.exists():
            d = json.loads(arq.read_text(encoding="utf-8"))
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Limiar p99", f"{d['limiar']:.4f}")
            c2.metric("Media baseline", f"{d['mu']:.4f}")
            c3.metric("Desvio baseline", f"{d['sigma']:.4f}")
            c4.metric("Epocas", f"{d.get('epochs_treinadas', '-')}")

            cola, colb = st.columns(2)
            p = PASTA_AE / "curva_treino.png"
            if p.exists():
                cola.image(str(p), caption="Curva de Treinamento",
                           use_container_width=True)
            p = PASTA_AE / "distribuicao_erro.png"
            if p.exists():
                colb.image(str(p), caption="Distribuicao do Erro",
                           use_container_width=True)
            p = PASTA_AE / "erro_temporal.png"
            if p.exists():
                st.image(str(p), caption="Erro de Reconstrucao Temporal",
                         use_container_width=True)
        else:
            st.info("Autoencoder ainda nao treinado.")

    # ── Injecao de falhas ────────────────────────────────────
    with st.expander("Injecao de Falhas Sinteticas (FMEA)", expanded=True):
        arq = PASTA_AE / "injecao_falhas_report.json"
        if arq.exists():
            d = json.loads(arq.read_text(encoding="utf-8"))
            st.caption(f"Limiar: {d['limiar']:.4f}  |  "
                       f"Baseline: {d['baseline_mean']:.4f} "
                       f"+/- {d['baseline_std']:.4f}")

            linhas = []
            for fid, f in d["falhas"].items():
                smd = d["smd"].get(fid)
                if smd:
                    erro = f["resultados"][str(smd)]["erro"]
                    marg = f["resultados"][str(smd)]["margem"]
                else:
                    erro = marg = None
                linhas.append({
                    "Falha"   : f["nome"],
                    "NPR"     : f["npr"] or "-",
                    "SMD"     : smd or "nao detectada",
                    "Erro SMD": f"{erro:.4f}" if erro else "-",
                    "Margem"  : f"{marg:.1f}x" if marg else "-",
                })
            st.dataframe(pd.DataFrame(linhas), use_container_width=True,
                         hide_index=True)

            cola, colb = st.columns(2)
            p = PASTA_AE / "injecao_falhas_resultados.png"
            if p.exists():
                cola.image(str(p), caption="Erro por Tipo e Severidade",
                           use_container_width=True)
            p = PASTA_AE / "injecao_falhas_comparacao.png"
            if p.exists():
                colb.image(str(p), caption="Comparacao (escala log)",
                           use_container_width=True)
        else:
            st.info("Injecao de falhas ainda nao executada.")

    # ── Validacao formal ─────────────────────────────────────
    with st.expander("Validacao Formal - AUC, F1, Recall", expanded=True):
        arq = PASTA_AE / "validacao_tabela.csv"
        if arq.exists():
            df = pd.read_csv(arq)
            melhores = df.loc[df.groupby("falha")["auc_roc"].idxmax()]
            cols_m = st.columns(len(melhores))
            for col, (_, row) in zip(cols_m, melhores.iterrows()):
                col.metric(
                    label=row["falha"][:18],
                    value=f"AUC {row['auc_roc']:.3f}",
                    delta=f"F1={row['f1']:.3f} sev={row['severidade']}"
                )

            df_show = df[["falha", "severidade", "f1", "auc_roc",
                          "recall", "precision"]].copy()
            df_show.columns = ["Falha", "Severidade", "F1", "AUC-ROC",
                               "Recall", "Precision"]
            st.dataframe(
                df_show.round(3).style.background_gradient(
                    subset=["F1", "AUC-ROC", "Recall"], cmap="YlGn"),
                use_container_width=True, hide_index=True
            )

            p = PASTA_AE / "validacao_roc.png"
            if p.exists():
                st.image(str(p), caption="Curvas ROC por Tipo de Falha",
                         use_container_width=True)
            cola, colb = st.columns(2)
            p = PASTA_AE / "validacao_matriz.png"
            if p.exists():
                cola.image(str(p), caption="Matrizes de Confusao",
                           use_container_width=True)
            p = PASTA_AE / "validacao_metricas.png"
            if p.exists():
                colb.image(str(p), caption="Heatmap de Metricas",
                           use_container_width=True)
        else:
            st.info("Validacao formal ainda nao executada.")

    # ── RUL / Weibull ────────────────────────────────────────
    with st.expander("RUL - Vida Util Remanescente (Weibull)", expanded=True):
        arq = PASTA_AE / "weibull_results.json"
        if arq.exists():
            d = json.loads(arq.read_text(encoding="utf-8"))
            linhas = []
            for fid, f in d["falhas"].items():
                p = f["weibull"]
                tipo = ("Crescente" if p["beta"] > 1.1
                        else "Constante" if p["beta"] > 0.9
                        else "Decrescente")
                linhas.append({
                    "Falha": f["nome"],
                    "NPR"  : f["npr"] or "D=10",
                    "Beta" : f"{p['beta']:.3f}",
                    "Eta"  : f"{p['eta']:.1f}",
                    "MTTF" : f"{p['mttf']:.1f}",
                    "B10"  : f"{p['b10']:.1f}",
                    "Taxa de falha": tipo,
                })
            st.caption("Beta > 1 confirma modelo de desgaste progressivo")
            st.dataframe(pd.DataFrame(linhas), use_container_width=True,
                         hide_index=True)

            cola, colb, colc = st.columns(3)
            p = PASTA_AE / "weibull_ttf.png"
            if p.exists():
                cola.image(str(p), caption="Distribuicao TTF + Weibull",
                           use_container_width=True)
            p = PASTA_AE / "weibull_confiabilidade.png"
            if p.exists():
                colb.image(str(p), caption="Funcoes de Confiabilidade",
                           use_container_width=True)
            p = PASTA_AE / "weibull_rul.png"
            if p.exists():
                colc.image(str(p), caption="RUL Condicional",
                           use_container_width=True)
        else:
            st.info("Analise de Weibull ainda nao executada.")


# ============================================================
# ABA - LITERATURA
# ============================================================

def renderizar_aba_literatura(colecao):
    """Lista os documentos indexados na base de conhecimento."""
    st.header("Literatura Indexada")
    from src.conhecimento.agente import listar_documentos
    st.metric("Total de chunks", colecao.count())
    st.divider()
    st.text(listar_documentos(colecao))


# ============================================================
# INTERFACE PRINCIPAL
# ============================================================

def main():
    for chave, valor in [
        ("mensagens",         []),
        ("llm",               None),
        ("nome_provedor",     "Nenhum"),
        ("caminho_sessao",    None),
        ("pergunta_pendente", None),
    ]:
        if chave not in st.session_state:
            st.session_state[chave] = valor

    try:
        perfil, modelo, colecao, colecao_sessoes, relatorio = carregar_base()
    except Exception as e:
        st.error(f"Erro ao carregar o agente: {e}")
        return

    renderizar_sidebar(modelo, colecao, colecao_sessoes)

    st.title("Al IAdo PV")
    st.caption("Assistente especialista em inversores fotovoltaicos - UTFPR")

    mostrar_novidades_orquestrador(relatorio)

    aba_chat, aba_ml, aba_lit = st.tabs([
        "Chat", "Resultados ML", "Literatura"
    ])

    # ── Aba Chat ─────────────────────────────────────────────
    with aba_chat:
        if st.session_state.llm is None:
            st.info("Selecione um provedor de LLM no painel lateral "
                    "e clique em Conectar provedor para comecar.")
        else:
            for msg in st.session_state.mensagens:
                with st.chat_message(msg["role"]):
                    st.markdown(msg["content"])

            if st.session_state.pergunta_pendente:
                pergunta = st.session_state.pergunta_pendente
                st.session_state.pergunta_pendente = None

                with st.chat_message("user"):
                    st.markdown(pergunta)

                from src.conhecimento.agente import preparar_prompt
                historico = [{"role": m["role"], "content": m["content"]}
                             for m in st.session_state.mensagens]

                with st.spinner("Buscando na literatura..."):
                    prompt, citacoes = preparar_prompt(
                        pergunta          = pergunta,
                        perfil            = perfil,
                        modelo_embeddings = modelo,
                        colecao           = colecao,
                        historico         = historico,
                        colecao_sessoes   = colecao_sessoes
                    )

                with st.chat_message("assistant"):
                    try:
                        resposta = st.write_stream(
                            stream_resposta(prompt, st.session_state.llm)
                        )
                        if citacoes:
                            st.divider()
                            st.caption("Fontes consultadas:")
                            for c in citacoes.values():
                                st.caption(f"- {c}")
                    except Exception as e:
                        if "429" in str(e):
                            st.error("Limite da API atingido. Troque o provedor.")
                        else:
                            st.error(f"Erro: {e}")
                        resposta = f"[Erro: {e}]"

                completa = resposta
                if citacoes:
                    completa += "\n\n**Fontes:** " + ", ".join(citacoes.values())

                st.session_state.mensagens.append(
                    {"role": "user", "content": pergunta})
                st.session_state.mensagens.append(
                    {"role": "assistant", "content": completa})

                n = len(st.session_state.mensagens) // 2
                salvar_sessao_streamlit(pergunta, completa, n, modelo)

    with aba_ml:
        renderizar_aba_ml()

    with aba_lit:
        renderizar_aba_literatura(colecao)

    # ── Input de chat - nivel superior, fixo no rodape ───────
    if st.session_state.llm is not None:
        if pergunta := st.chat_input("Digite sua pergunta..."):
            st.session_state.pergunta_pendente = pergunta
            st.rerun()


if __name__ == "__main__":
    main()